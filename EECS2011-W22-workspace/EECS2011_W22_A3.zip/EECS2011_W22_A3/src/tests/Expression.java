package tests;

/*
 * A class used by the StarterTests.
 * You must use this class as is without modifying it.
 */

public abstract class Expression {

}
